export function notFoundMiddleware(
  req,
  res
) {
  return res.status(404).json({
    success: false,
    message: "Route not found.",
    path: req.originalUrl,
    method: req.method,
  });
}

export default notFoundMiddleware;